<body>
<form action="4c-012b.php" method="post" enctype="multipart/form-data"> 
ファイル：  <input type="file" name="imgfile" size="20"><br>
<input type="submit" value="アップロード">
</form>
</body>
